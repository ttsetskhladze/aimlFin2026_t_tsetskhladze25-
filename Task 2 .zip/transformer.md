# Transformer Networks
## AI and Machine Learning for Cybersecurity — Final Exam, Task 2
Topic: Transformer Architecture — Theory, Mechanisms, and Cybersecurity Applications



## 1. Introduction

The **Transformer** is a deep learning architecture introduced by Vaswani et al. in the seminal 2017 paper *"Attention Is All You Need."* It replaced recurrent connections (RNNs, LSTMs) with a mechanism called **self-attention**, allowing every position in a sequence to directly attend to every other position — regardless of distance. This single insight unlocked:

- **Massive parallelism** during training (no sequential dependency),
- **Long-range dependency capture** without gradient degradation,
- **Scalability** to billions of parameters.

Today, Transformers underpin virtually every state-of-the-art model in NLP (BERT, GPT-4, T5), vision (ViT), protein folding (AlphaFold), and increasingly, **cybersecurity** — where sequential and contextual reasoning over logs, traffic flows, and threat reports is critical.

---

## 2. Historical Context

| Era | Architecture | Limitation |

| Pre-2014 | RNN, vanilla | Vanishing gradients, no parallelism |
| 2014–2017 | LSTM, GRU | Better memory, still sequential |
| 2015 | Seq2Seq + Attention | Attention addon to RNN encoder-decoder |
| **2017** | **Transformer** | **Attention only, fully parallel** |
| 2018 | BERT, GPT | Pretrain-then-finetune paradigm |
| 2020+ | GPT-3, T5, LLaMA | Scaling laws, few-shot learning |

The key insight was eliminating recurrence entirely and making attention the **sole** information routing mechanism — hence the paper's title.

---

## 3. High-Level Architecture

![Transformer Architecture](transformer_architecture.png)

*Figure 1 — Complete Transformer architecture. The encoder (blue, left) processes the source sequence; the decoder (red, right) generates the output sequence one token at a time. The yellow arrow shows cross-attention, where the decoder queries the encoder's memory.*

The Transformer follows an **Encoder-Decoder** design:

- The **Encoder** maps an input sequence `(x₁, …, xₙ)` to a sequence of continuous representations `z = (z₁, …, zₙ)`.
- The **Decoder** generates an output sequence `(y₁, …, yₘ)` one element at a time, conditioned on `z` and the already-generated tokens.

Each encoder and decoder is composed of **N identical stacked layers** (N = 6 in the original paper). Each layer contains two (encoder) or three (decoder) sub-layers, connected via **residual connections** and **layer normalization**.

---

## 4. Core Mechanisms

### 4.1 Input Embeddings

Raw tokens (words, bytes, characters) are first mapped to dense vectors of dimension `d_model` (512 in the original paper) via a learned **embedding matrix** `E ∈ ℝ^{|vocab| × d_model}`. The embedding weights are **shared** between the encoder, decoder input, and the pre-softmax linear layer — reducing total parameters.

---

### 4.2 Positional Encoding

Since the Transformer has no built-in notion of sequence order (unlike RNNs), **positional information must be explicitly injected** into the embeddings. The original paper uses deterministic sinusoidal encodings:

$$PE_{(pos,\ 2i)}   = \sin\!\left(\frac{pos}{10000^{2i / d_{model}}}\right)$$

$$PE_{(pos,\ 2i+1)} = \cos\!\left(\frac{pos}{10000^{2i / d_{model}}}\right)$$

where `pos` is the token position and `i` is the dimension index. These are **added** (not concatenated) to the token embeddings: `input = Embedding(token) + PE(pos)`.

![Positional Encoding](positional_encoding.png)

*Figure 2 — Left: the full PE matrix for 60 positions and 64 dimensions. Each column is a unique position fingerprint. Right: individual dimension curves. Low-index dimensions oscillate rapidly (high frequency, encode fine position), while high-index dimensions vary slowly (low frequency, encode coarse position). Together they form a unique, distance-preserving code for every position.*

**Why sinusoids?** The model can learn to attend to relative positions because `PE(pos + k)` is a linear transformation of `PE(pos)` for any fixed offset `k`. Modern models (BERT, GPT) often use **learned positional embeddings** instead.

---

### 4.3 Scaled Dot-Product Attention

The fundamental building block is **Scaled Dot-Product Attention**:

$$\text{Attention}(Q, K, V) = \text{softmax}\!\left(\frac{QK^\top}{\sqrt{d_k}}\right)V$$

where:

| Symbol | Name | Shape | Role |
|--------|------|-------|------|
| `Q` | Queries | `(seq_len, d_k)` | "What am I looking for?" |
| `K` | Keys | `(seq_len, d_k)` | "What do I contain?" |
| `V` | Values | `(seq_len, d_v)` | "What do I return if matched?" |
| `d_k` | Key dimension | scalar | Scaling factor |

**Step-by-step:**

1. Compute raw similarity scores: `scores = Q · Kᵀ` → shape `(seq_len, seq_len)`
2. Scale by `√d_k` to prevent dot products from growing too large (which pushes softmax into saturation regions with vanishing gradients)
3. Apply optional **mask** — in the decoder, future positions are masked with `-∞` before softmax to enforce auto-regression
4. Apply **softmax** row-wise to get normalized attention weights summing to 1
5. Compute weighted sum of values: `output = softmax(scores) · V`

![Attention Mechanism](attention_mechanism.png)

*Figure 3 — Left: the step-by-step data flow through Scaled Dot-Product Attention. Right: an example attention weight heatmap for a short IDS log token sequence. Brighter cells indicate higher attention — note "detect" strongly attends to "scan", and "host" strongly attends to the IP address token, mimicking semantic understanding.*

---

### 4.4 Multi-Head Attention

A single attention head computes one type of relationship. **Multi-Head Attention** runs `h` attention heads **in parallel**, each with its own learned projection matrices:

$$\text{MultiHead}(Q, K, V) = \text{Concat}(\text{head}_1, \ldots, \text{head}_h)\, W^O$$

$$\text{head}_i = \text{Attention}(Q W_i^Q,\ K W_i^K,\ V W_i^V)$$

Each head projects into a `d_k = d_model / h` dimensional subspace, allowing different heads to specialize in different relationship types (e.g., syntactic, semantic, positional dependencies).

![Multi-Head Attention](multihead_attention.png)

*Figure 4 — Multi-Head Attention with h=8 heads. Each colored head independently computes attention in its own subspace. Outputs are concatenated and projected through W_O back to d_model dimensions. This enables the model to jointly attend to information from different representation subspaces.*

---

### 4.5 Feed-Forward Sub-layer

After the attention sub-layer, each position passes through a **position-wise Feed-Forward Network (FFN)** — the same two-layer MLP applied independently to every position:

$$\text{FFN}(x) = \max(0,\ xW_1 + b_1)\, W_2 + b_2$$

The inner dimension is typically expanded to `4 × d_model` (e.g., 2048 for `d_model = 512`). This layer stores and retrieves **factual knowledge** — recent research shows that FFN layers act as key-value memory stores.

---

### 4.6 Add & LayerNorm (Residual Connections)

Every sub-layer (attention and FFN) is wrapped with a **residual connection** and **Layer Normalization**:

$$\text{output} = \text{LayerNorm}(x + \text{SubLayer}(x))$$

Residual connections allow gradients to flow directly to early layers during backpropagation, making very deep networks trainable. Layer Normalization normalizes across the feature dimension within each token, stabilizing training independent of batch size.

---

## 5. Encoder vs. Decoder

| Feature | Encoder | Decoder |
|---------|---------|---------|
| Attention type | Bidirectional self-attention | Masked (causal) self-attention + cross-attention |
| Input | Full source sequence | Prefix of generated tokens |
| Output | Contextual representations (K, V memory) | Probability distribution over next token |
| Used in | BERT, RoBERTa, CyBERT | GPT, T5, CodeGen |
| Cybersec task | Classification, NER, anomaly detection | Log generation, threat report summarization |

**Encoder-only models** (BERT-style) read the whole sequence at once — ideal for classification tasks.
**Decoder-only models** (GPT-style) generate text autoregressively — ideal for generation tasks.
**Encoder-Decoder models** (T5-style) are best for sequence-to-sequence tasks like translation or summarization.

---

## 6. Transformer Variants

| Model | Type | Key Innovation | Cybersec Use |
|-------|------|----------------|--------------|
| **BERT** | Encoder | Masked Language Modeling | Log classification, threat NER |
| **GPT-4** | Decoder | RLHF + scaling | Threat report generation, red-teaming |
| **T5** | Enc-Dec | Text-to-text unified format | CTI summarization |
| **CyBERT** | Encoder | Domain pretrain on security text | CVE/IOC extraction |
| **SecBERT** | Encoder | Pretrained on NVD, MITRE ATT&CK | Vulnerability classification |
| **ViT** | Encoder | Image patches as tokens | Malware visualization classification |
| **CodeBERT** | Encoder | Code + NL pretraining | Vulnerability detection in source code |

---

## 7. Training Transformers

### Pre-training objectives

| Objective | Model family | Description |
|-----------|-------------|-------------|
| **MLM** (Masked LM) | BERT | Predict randomly masked tokens from context |
| **NSP** (Next Sentence Prediction) | BERT | Predict if two sentences are consecutive |
| **CLM** (Causal LM) | GPT | Predict next token given left context |
| **Span corruption** | T5 | Predict randomly replaced spans |

### Fine-tuning for cybersecurity

```
Pre-trained Transformer
         │
    [Freeze base or use low learning rate]
         │
    Domain-specific data
    (CVE descriptions, network logs,
     malware reports, SIEM alerts)
         │
    Task head (classifier / NER / seq2seq)
         │
    Fine-tuned Cybersecurity Model
```

**Key hyperparameters:**

| Parameter | Typical Range |
|-----------|--------------|
| Learning rate | 1e-5 to 5e-5 |
| Warm-up steps | 5–10% of total steps |
| Batch size | 16–64 |
| Epochs | 3–10 |
| Optimizer | AdamW with weight decay |
| Scheduler | Linear decay or cosine annealing |

---

## 8. Applications in Cybersecurity

![Cybersecurity Applications](cybersecurity_applications.png)

*Figure 5 — Overview of Transformer applications across the cybersecurity domain. Each node represents a major application area, with the Transformer model at the center enabling all of them.*

---

### 8.1 Intrusion Detection Systems

Transformers model **network traffic as a sequence of flow-feature vectors** or raw packets. The attention mechanism naturally captures temporal correlations between flows — for example, a SYN scan followed by rapid connections is a recognizable pattern across multiple timesteps.

**Architecture:** 1D-Transformer encoder applied to standardized flow records from datasets like CICIDS-2017. The `[CLS]` token embedding is passed to a classification head.

**Key results:** Models like NetTransformer and BERT4IDS achieve >98% F1 on benchmark datasets, outperforming CNN and LSTM baselines — particularly on low-volume, slow-burn attacks like APTs that require long-context reasoning.

---

### 8.2 Malware Analysis

Malware binaries can be interpreted as **byte sequences** — analogous to words in a sentence. Transformer encoders pretrained on large corpora of benign and malicious binaries learn byte-level semantics.

**Applications:**
- **Static analysis**: Classify PE/ELF files without execution from raw bytes
- **Obfuscation resistance**: Attention over full byte sequences is less fooled by padding/junk insertion than signature scanners
- **Malware family attribution**: Fine-grained multi-class classification

**Notable model:** MalBERT — BERT fine-tuned on disassembled malware source code — achieves 96%+ accuracy on malware family classification (Kaspersky dataset).

---

### 8.3 Log Analysis and Anomaly Detection

SIEM platforms generate millions of log lines per day. Transformers offer:

- **Semantic parsing**: Understand structured (`syslog`, `Windows Event Log`, `nginx`) and semi-structured logs as natural language
- **Anomaly detection**: Fine-tune a masked language model on normal logs; flag sequences where the predicted token probability is low (indicating novel/anomalous events)
- **Session modeling**: Encode sequences of events (login → privilege escalation → lateral movement) as structured narratives

**Example workflow:**

```
Raw syslog line:
"Jan 15 03:42:11 webserver sshd[1234]: Failed password for root from 192.168.1.55"

Transformer tokenizes → attends to [Failed][root][192.168.1.55] as high-risk co-occurrence
→ Outputs anomaly score: 0.94  (threshold: 0.7 → ALERT)
```

---

### 8.4 Cyber Threat Intelligence (CTI) NLP

CTI reports from vendors (Mandiant, CrowdStrike, Talos) contain rich threat information buried in unstructured text. Transformers power:

- **Named Entity Recognition (NER)**: Automatically extract IOCs (IPs, hashes, CVEs, threat actor names) using BERT fine-tuned on annotated CTI corpora
- **Relation extraction**: Identify that *"APT29 uses Cobalt Strike for C2"* establishes an actor–tool relationship
- **MITRE ATT&CK mapping**: Classify TTPs described in reports to ATT&CK technique IDs
- **Report summarization**: T5/LLM-based abstractive summarization of lengthy incident reports

**Dataset:** APTNER, CyNER, and SecureNLP corpora provide domain-specific annotated training data.

---

### 8.5 Phishing and Spam Detection

Phishing detection is fundamentally a **text classification** problem — one where subtle linguistic cues (urgency, authority impersonation, homoglyph characters) are the primary signal.

**BERT-based classifiers** outperform keyword-based and TF-IDF approaches because they:

- Understand paraphrase and semantic similarity (phishing variants that avoid keyword blocklists)
- Process URL structure, anchor text, and body text jointly
- Detect zero-day phishing by reasoning about content rather than matching signatures

**Key metric:** State-of-the-art BERT phishing detectors achieve >99% accuracy on public datasets (Enron spam, PhishTank), with false positive rates below 0.1%.

---

### 8.6 Vulnerability Prediction and Code Analysis

**CodeBERT** and **GraphCodeBERT** are pre-trained on code + natural language pairs. Fine-tuned on vulnerability datasets (NVD, CVEfixes), they can:

- Predict whether a code function contains a vulnerability (binary classification)
- Identify the vulnerability type (buffer overflow, SQL injection, use-after-free)
- Generate natural language descriptions of vulnerabilities from code
- Assist in patch suggestion (encoder-decoder mode)

**Benchmark:** On BigVul dataset (vulnerability detection), transformer-based models achieve 72–80% F1, significantly surpassing static analysis tools and simpler neural approaches.

---

## 9. Strengths and Limitations

### Strengths

| Property | Benefit in Cybersecurity |
|----------|--------------------------|
| Long-range attention | Captures multi-step attack sequences across long logs |
| Parallelism | Fast training on large security datasets (millions of flows) |
| Transfer learning | Pretrain once, fine-tune cheaply for new threat classes |
| Bidirectional context | Full context understanding for log/CTI analysis |
| Scalability | Performance improves reliably with more data and parameters |

### Limitations

| Limitation | Impact | Mitigation |
|------------|--------|-----------|
| Quadratic attention cost O(n²) | Slow on very long sequences (packet captures) | Sparse/linear attention (Longformer, Performer) |
| Large data requirements | Fine-tuning needs labeled security data | Few-shot learning, data augmentation |
| Black-box decisions | Hard to audit in regulated environments | Attention visualization, SHAP explanations |
| Adversarial vulnerability | Adversarial inputs can fool classifiers | Adversarial training, certified robustness |
| Computational cost | Expensive to deploy at line-rate | Distillation (DistilBERT), quantization |

---

## 10. Summary

The Transformer architecture revolutionized sequence modelling through three core innovations: **sinusoidal positional encoding** to inject order without recurrence, **scaled dot-product attention** to route information based on content similarity, and **multi-head attention** to capture diverse relationship types in parallel.

In cybersecurity, Transformers have become the dominant approach for any task involving **sequential or textual data** — network flows, malware bytes, system logs, threat reports, and source code. Pre-trained models like BERT and its security-domain descendants (CyBERT, SecBERT, MalBERT) enable practitioners to achieve high-accuracy detection with relatively small amounts of labeled security data, dramatically accelerating the development of intelligent threat detection systems.

As adversaries increasingly use automation and AI, defenders equipped with Transformer-based tools have a powerful, adaptive, and scalable counterpart — making transformer literacy an essential skill for the modern cybersecurity practitioner.

