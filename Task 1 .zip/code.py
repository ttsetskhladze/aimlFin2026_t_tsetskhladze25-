"""
cnn_ids.py
══════════════════════════════════════════════════════════════════
CNN-based Network Intrusion Detection System
AI and ML for Cybersecurity — Final Exam, Task 1

Run:
    pip install tensorflow numpy scikit-learn matplotlib
    python cnn_ids.py

Outputs:
    cnn_training_history.png  — loss and accuracy curves
    cnn_confusion_matrix.png  — normalized confusion matrix
    (console)                 — classification report + test accuracy
══════════════════════════════════════════════════════════════════
"""

import itertools
import random

import matplotlib
matplotlib.use('Agg')          # headless — no display needed
import matplotlib.pyplot as plt
import numpy as np
from sklearn.metrics import (accuracy_score, classification_report,
                             confusion_matrix)
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

import tensorflow as tf
from tensorflow.keras import callbacks, layers, models

# ── Reproducibility ──────────────────────────────────────────────
SEED = 42
random.seed(SEED)
np.random.seed(SEED)
tf.random.set_seed(SEED)

# ════════════════════════════════════════════════════════════════
# 1.  SYNTHETIC DATASET
# ════════════════════════════════════════════════════════════════
N_PER_CLASS = 1000
N_FEATURES  = 20
CLASS_NAMES = ["Benign", "DoS", "PortScan", "SQLInjection", "BruteForce"]

FEATURE_NAMES = [
    "flow_duration",      "total_fwd_pkts",     "total_bwd_pkts",
    "total_len_fwd_pkts", "total_len_bwd_pkts",  "fwd_pkt_len_mean",
    "bwd_pkt_len_mean",   "flow_bytes_s",         "flow_pkts_s",
    "flow_iat_mean",      "fwd_iat_mean",          "bwd_iat_mean",
    "fwd_psh_flags",      "bwd_psh_flags",         "fwd_rst_flags",
    "pkt_len_variance",   "fin_flag_cnt",          "syn_flag_cnt",
    "rst_flag_cnt",       "urg_flag_cnt",
]

# Each entry: (means_list, stds_list) for the 20 features
CLASS_PARAMS = {
    "Benign": (
        [50,30,20,1500,1200,50,40,5000,10,200,300,400,0,0,0,100,0,0,0,0],
        [20,15,10,800,600,20,15,2000,5,100,150,200,0.1,0.1,0.1,50,0.1,0.1,0.1,0.1],
    ),
    "DoS": (
        [5,500,2,25000,100,50,50,500000,500,10,10,500,1,0,0,200,0,1,0,0],
        [3,200,2,5000,100,10,10,100000,100,5,5,200,0.3,0.1,0.1,100,0.1,0.3,0.1,0.1],
    ),
    "PortScan": (
        [1,1,1,60,0,60,0,1000,5,500,500,0,0,0,1,10,0,1,1,0],
        [0.5,0.5,0.5,20,1,5,1,500,2,200,200,1,0.1,0.1,0.3,5,0.1,0.3,0.3,0.1],
    ),
    "SQLInjection": (
        [30,5,5,500,500,100,100,3000,3,300,300,300,0,0,0,50,0,0,0,1],
        [10,3,3,200,200,30,30,1000,1,100,100,100,0.1,0.1,0.1,20,0.1,0.1,0.1,0.3],
    ),
    "BruteForce": (
        [200,50,50,3000,3000,60,60,2000,2,1000,1000,1000,0,0,0,30,0,0,0,0],
        [50,20,20,1000,1000,10,10,500,1,300,300,300,0.1,0.1,0.1,10,0.1,0.1,0.1,0.1],
    ),
}


def build_dataset():
    """Generate synthetic traffic data and return train/val/test splits."""
    X_parts, y_parts = [], []
    for idx, (label, (means, stds)) in enumerate(CLASS_PARAMS.items()):
        X_cls = np.random.normal(
            loc=np.array(means), scale=np.array(stds),
            size=(N_PER_CLASS, N_FEATURES)
        )
        X_cls = np.clip(X_cls, 0, None)   # flow features are non-negative
        X_parts.append(X_cls)
        y_parts.extend([idx] * N_PER_CLASS)

    X_raw = np.vstack(X_parts)
    y     = np.array(y_parts)

    # Shuffle
    idx_order = np.random.permutation(len(y))
    X_raw, y  = X_raw[idx_order], y[idx_order]

    # Standardize
    scaler   = StandardScaler()
    X_scaled = scaler.fit_transform(X_raw)

    # Reshape to (samples, timesteps, channels) for 1D-CNN
    X_cnn = X_scaled.reshape(-1, N_FEATURES, 1)

    # 70 / 15 / 15 split
    X_train, X_tmp, y_train, y_tmp = train_test_split(
        X_cnn, y, test_size=0.30, random_state=SEED, stratify=y)
    X_val, X_test, y_val, y_test   = train_test_split(
        X_tmp, y_tmp, test_size=0.50, random_state=SEED, stratify=y_tmp)

    print(f"Dataset splits — "
          f"Train: {X_train.shape}, Val: {X_val.shape}, Test: {X_test.shape}")
    return X_train, X_val, X_test, y_train, y_val, y_test


# ════════════════════════════════════════════════════════════════
# 2.  MODEL DEFINITION
# ════════════════════════════════════════════════════════════════
def build_cnn_ids(input_shape=(N_FEATURES, 1), n_classes=5):
    """
    1D-CNN architecture for network intrusion detection.
    """
    model = models.Sequential([
        layers.Conv1D(32, kernel_size=3, padding='same',
                      activation='relu', input_shape=input_shape,
                      name='conv1'),
        layers.BatchNormalization(name='bn1'),

        layers.Conv1D(64, kernel_size=3, padding='same',
                      activation='relu', name='conv2'),
        layers.BatchNormalization(name='bn2'),

        layers.GlobalMaxPooling1D(name='global_pool'),

        layers.Dense(128, activation='relu', name='fc1'),
        layers.Dropout(0.4, name='drop1'),

        layers.Dense(64, activation='relu', name='fc2'),
        layers.Dropout(0.3, name='drop2'),

        layers.Dense(n_classes, activation='softmax', name='output'),
    ], name='CNN_IDS')

    return model


# ════════════════════════════════════════════════════════════════
# 3.  PLOTTING HELPERS
# ════════════════════════════════════════════════════════════════
DARK_BG  = '#0d1117'
PANEL_BG = '#161b22'
GRID_COL = '#30363d'
TICK_COL = '#8b949e'


def style_ax(ax):
    ax.set_facecolor(PANEL_BG)
    ax.tick_params(colors=TICK_COL)
    for sp in ax.spines.values():
        sp.set_edgecolor(GRID_COL)
    ax.grid(alpha=0.15, color=TICK_COL)


def plot_training_history(history, save_path='cnn_training_history.png'):
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))
    fig.patch.set_facecolor(DARK_BG)

    epochs = range(1, len(history.history['loss']) + 1)

    for ax in (ax1, ax2):
        style_ax(ax)

    ax1.plot(epochs, history.history['loss'],
             color='#f85149', lw=2, label='Train Loss')
    ax1.plot(epochs, history.history['val_loss'],
             color='#388bfd', lw=2, linestyle='--', label='Val Loss')
    ax1.set_title('Loss Curve', color='white', fontweight='bold', fontsize=12)
    ax1.set_xlabel('Epoch', color=TICK_COL)
    ax1.set_ylabel('Loss',  color=TICK_COL)
    ax1.legend(facecolor=DARK_BG, labelcolor='white')

    ax2.plot(epochs, history.history['accuracy'],
             color='#3fb950', lw=2, label='Train Acc')
    ax2.plot(epochs, history.history['val_accuracy'],
             color='#f0883e', lw=2, linestyle='--', label='Val Acc')
    ax2.set_title('Accuracy Curve', color='white', fontweight='bold', fontsize=12)
    ax2.set_xlabel('Epoch',    color=TICK_COL)
    ax2.set_ylabel('Accuracy', color=TICK_COL)
    ax2.legend(facecolor=DARK_BG, labelcolor='white')

    fig.suptitle('CNN IDS — Training History',
                 color='white', fontsize=14, fontweight='bold')
    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches='tight', facecolor=DARK_BG)
    plt.close()
    print(f"Saved → {save_path}")


def plot_confusion_matrix(y_true, y_pred, class_names,
                          save_path='cnn_confusion_matrix.png'):
    cm      = confusion_matrix(y_true, y_pred)
    cm_norm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
    n       = len(class_names)

    fig, ax = plt.subplots(figsize=(8, 7))
    fig.patch.set_facecolor(DARK_BG)
    ax.set_facecolor(DARK_BG)

    ax.imshow(cm_norm, cmap='Blues', vmin=0, vmax=1)
    ax.set_xticks(range(n))
    ax.set_yticks(range(n))
    ax.set_xticklabels(class_names, rotation=30, ha='right', color=TICK_COL)
    ax.set_yticklabels(class_names, color=TICK_COL)
    ax.set_xlabel('Predicted Label', color=TICK_COL, fontsize=10)
    ax.set_ylabel('True Label',      color=TICK_COL, fontsize=10)
    ax.set_title('Confusion Matrix (Normalized)',
                 color='white', fontweight='bold', fontsize=12)

    for i, j in itertools.product(range(n), range(n)):
        color = 'white' if cm_norm[i, j] > 0.5 else '#c0c0c0'
        ax.text(j, i, f'{cm_norm[i, j]:.2f}',
                ha='center', va='center', color=color, fontsize=10)

    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches='tight', facecolor=DARK_BG)
    plt.close()
    print(f"Saved → {save_path}")


# ════════════════════════════════════════════════════════════════
# 4.  MAIN
# ════════════════════════════════════════════════════════════════
if __name__ == '__main__':

    # 4a. Data
    X_train, X_val, X_test, y_train, y_val, y_test = build_dataset()

    # 4b. Model
    model = build_cnn_ids()
    model.summary()

    model.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate=1e-3),
        loss='sparse_categorical_crossentropy',
        metrics=['accuracy'],
    )

    # 4c. Callbacks
    early_stop = callbacks.EarlyStopping(
        monitor='val_loss', patience=8, restore_best_weights=True, verbose=1)
    reduce_lr = callbacks.ReduceLROnPlateau(
        monitor='val_loss', factor=0.5, patience=4, min_lr=1e-6, verbose=1)

    # 4d. Train
    history = model.fit(
        X_train, y_train,
        validation_data=(X_val, y_val),
        epochs=50,
        batch_size=64,
        callbacks=[early_stop, reduce_lr],
        verbose=1,
    )

    # 4e. Evaluate
    y_pred_prob = model.predict(X_test)
    y_pred      = np.argmax(y_pred_prob, axis=1)

    acc = accuracy_score(y_test, y_pred)
    print(f"\n{'='*50}")
    print(f"  Test Accuracy : {acc:.4f}  ({acc*100:.2f}%)")
    print(f"{'='*50}\n")
    print(classification_report(y_test, y_pred, target_names=CLASS_NAMES))

    # 4f. Plots
    plot_training_history(history)
    plot_confusion_matrix(y_test, y_pred, CLASS_NAMES)

    print("\nDone. Check cnn_training_history.png and cnn_confusion_matrix.png")
